<!-- Javascript -->
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery-migrate-3.3.2.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/bootstrap.min.js') }}"></script> 
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery.easing.js') }}"></script> 
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery-waypoints.js') }}"></script>    
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery-validate.js') }}"></script> 
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery.prettyPhoto.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/slick.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/numinate.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/circle-progress.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/imagesloaded.min.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/jquery-isotope.js') }}"></script>
<script src="{{ asset((!\App::environment('local') ? 'public/' : '') . 'storage/js/main.js') }}"></script>