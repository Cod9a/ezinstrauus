<!-- preloader start -->
<div id="preloader" class="blobs-wrapper">
    <div class="ttm-bgcolor-skincolor loader"></div>
</div>
<!-- preloader end --> 