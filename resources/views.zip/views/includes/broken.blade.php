<!-- broken-section --> 
<section class="ttm-row broken-section mb_70 res-991-margin_bottom0 bg-gradient clearfix">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="featuredbox-number">
                    <div class="row ">
                        <div class="col-lg-6 col-md-6">
                            <div class="ttm-fid inside ttm-fid-view-circle-progress ttm-fid-with-border style2">
                                <div class="ttm-fid-contents ">
                                    <div class="ttm-circle-box"
                                        data-digit          = "92"
                                        data-fill           = "#8cbc43"
                                        data-before         = ""
                                        data-before-type    = "sup"
                                        data-after          = "%"
                                        data-after-type     = "span"
                                        data-size           = "100"
                                        data-emptyfill      = "rgba(140,188,67,.1)"
                                        data-thickness      = "5"
                                        data-linecap        = "round"
                                        data-gradient       = ""
                                        >
                                        <div class="ttm-circle-content">
                                            <div class="ttm-circle"></div>
                                            <div class="ttm-circle-boxcontent">
                                                <div class="ttm-fid-number"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ttm-fid-title-after-circle">
                                    <h3 class="ttm-fid-title">Success Rate</h3>
                                    <div>Completed most of the projects with the many  client satisfaction much more</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="ttm-fid inside ttm-fid-view-circle-progress ttm-fid-with-border style2 res-767-margin_top30">
                                <div class="ttm-fid-contents ">
                                    <div class="ttm-circle-box"
                                        data-digit          = "85"
                                        data-fill           = "#8cbc43"
                                        data-before         = ""
                                        data-before-type    = "sup"
                                        data-after          = "K"
                                        data-after-type     = "span"
                                        data-size           = "100"
                                        data-emptyfill      = "rgba(140,188,67,.1)"
                                        data-thickness      = "5"
                                        data-linecap        = "round"
                                        data-gradient       = ""
                                        >
                                        <div class="ttm-circle-content">
                                            <div class="ttm-circle"></div>
                                            <div class="ttm-circle-boxcontent">
                                                <div class="ttm-fid-number"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ttm-fid-title-after-circle">
                                    <h3 class="ttm-fid-title">Customer Reviews</h3>
                                    <div>Customers are send and we owned clients worldwide with satisfactory reviews.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!-- broken-section end -->